# EMS CONNECT reusable starter

Read REUSE-GUIDE.md first.

```sh
npm ci
npm run dev
```

No database credentials or production patient data included. reference-sql is NOT a fresh-database bootstrap.
