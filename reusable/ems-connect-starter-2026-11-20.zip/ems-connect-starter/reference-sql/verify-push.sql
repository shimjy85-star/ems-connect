-- Read-only permission checks, followed by a rolled-back test using the authorized fake reservation.
select
  not has_function_privilege('anon','public.verify_dispatch_worker(text)','execute') as anon_worker_denied,
  not has_function_privilege('authenticated','public.claim_dispatch_push()','execute') as user_queue_denied,
  not has_function_privilege('authenticated','public.invoke_dispatch_push()','execute') as user_invoke_denied,
  not has_table_privilege('authenticated','public.push_subscriptions','select') as user_subscriptions_denied,
  not has_table_privilege('authenticated','public.dispatch_push_queue','update') as user_queue_write_denied,
  not public.verify_dispatch_worker(repeat('0',64)) as invalid_secret_denied;

begin;
update public.reservations set status='confirmed',driver_id='YOUR_DRIVER_PROFILE_UUID',
  vehicle_id='YOUR_VEHICLE_UUID'
where id='YOUR_TEST_RESERVATION_UUID';
select reservation_id,driver_id,sent_at is null as pending from public.dispatch_push_queue
where reservation_id='YOUR_TEST_RESERVATION_UUID';
select count(*) as first_claim from public.claim_dispatch_push();
select count(*) as concurrent_claim_should_be_zero from public.claim_dispatch_push();
rollback;
