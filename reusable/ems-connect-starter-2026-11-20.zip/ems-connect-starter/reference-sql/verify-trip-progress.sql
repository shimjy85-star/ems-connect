begin;
update public.reservations set status='confirmed',driver_id='YOUR_DRIVER_PROFILE_UUID',vehicle_id='YOUR_VEHICLE_UUID' where id='YOUR_TEST_RESERVATION_UUID';
select set_config('request.jwt.claim.sub','YOUR_DRIVER_PROFILE_UUID',true);
set local role authenticated;
do $$ declare rid uuid:='YOUR_TEST_RESERVATION_UUID'; begin
  begin
    perform public.advance_trip(rid,'assigned','completed');
    raise exception 'TEST FAILED: skipped phase';
  exception when others then
    if sqlerrm<>'운행 상태가 변경됐거나 처리 순서가 맞지 않습니다. 새로고침해 주세요.' then raise; end if;
  end;
  perform public.advance_trip(rid,'assigned','moving');
  if not exists(select 1 from public.reservations where id=rid and status='in_progress' and trip_phase='moving') then raise exception 'moving failed'; end if;
  begin
    perform public.advance_trip(rid,'assigned','moving');
    raise exception 'TEST FAILED: duplicate phase';
  exception when others then
    if sqlerrm<>'운행 상태가 변경됐거나 처리 순서가 맞지 않습니다. 새로고침해 주세요.' then raise; end if;
  end;
  perform public.advance_trip(rid,'moving','transporting');
  perform public.advance_trip(rid,'transporting','completed');
  if not exists(select 1 from public.reservations where id=rid and status='completed' and trip_phase='completed') then raise exception 'completion failed'; end if;
end $$;
select set_config('request.jwt.claim.sub','YOUR_TEST_HOSPITAL_PROFILE_UUID',true);
do $$ begin
  begin
    perform public.advance_trip('YOUR_TEST_RESERVATION_UUID','assigned','moving');
    raise exception 'TEST FAILED: hospital changed trip';
  exception when others then
    if sqlerrm<>'활성 기사 계정으로 로그인해 주세요.' then raise; end if;
  end;
end $$;
select 'Trip sequence, duplicate/skip prevention and hospital denial passed; rolling back' as result;
rollback;
