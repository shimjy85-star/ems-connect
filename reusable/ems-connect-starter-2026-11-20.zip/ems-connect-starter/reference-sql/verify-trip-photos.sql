begin;
update public.reservations set status='completed',driver_id='YOUR_DRIVER_PROFILE_UUID',vehicle_id='YOUR_VEHICLE_UUID'
where id='YOUR_TEST_RESERVATION_UUID';
select set_config('request.jwt.claim.sub','YOUR_DRIVER_PROFILE_UUID',true);
set local role authenticated;
do $$ begin
  if not public.can_access_trip_photo('YOUR_TEST_RESERVATION_UUID/photo.jpg',true) then raise exception 'Assigned driver cannot upload'; end if;
  if public.can_access_trip_photo('YOUR_TEST_RESERVATION_UUID/other.jpg',true) then raise exception 'Unexpected object accepted'; end if;
end $$;
select set_config('request.jwt.claim.sub','YOUR_TEST_HOSPITAL_PROFILE_UUID',true);
do $$ begin
  if not public.can_access_trip_photo('YOUR_TEST_RESERVATION_UUID/photo.jpg',false) then raise exception 'Own hospital cannot download'; end if;
  if public.can_access_trip_photo('YOUR_TEST_RESERVATION_UUID/photo.jpg',true) then raise exception 'Hospital can upload'; end if;
end $$;
reset role;
-- Change only the fake booking's hospital inside this rollback transaction.
update public.reservations set hospital_id=(select id from public.hospitals where id<>(select hospital_id from public.profiles where id='YOUR_TEST_HOSPITAL_PROFILE_UUID') limit 1)
where id='YOUR_TEST_RESERVATION_UUID';
set local role authenticated;
do $$ begin
  if public.can_access_trip_photo('YOUR_TEST_RESERVATION_UUID/photo.jpg',false) then raise exception 'Other hospital can download'; end if;
end $$;
select 'Driver upload, own hospital download, other hospital denial passed; rolling back' as result;
rollback;
